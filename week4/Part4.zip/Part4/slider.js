function Slider(sliderId, textId, value, callback, transform) {
  this._slider = document.getElementById(sliderId)
  this._text = document.getElementById(textId)
  this._transform = transform || function (v) { return v }
  this._callback = callback || function () { }

  if (this._slider == null) {
    console.error("Slider(): #" + sliderId + " not found.", arguments, this)
  }
  if (this._text == null) {
    console.error("Slider(): #" + textId + " not found.", arguments, this)
  }

  this._slider.addEventListener("input", function (e) {
    this.set(e.target.value)
  }.bind(this))

  this.set(value)
}

Slider.prototype.set = function (value) {
  var transformedValue = this._transform(value)
  this._slider.value = transformedValue
  this._text.innerHTML = transformedValue
  this._callback(transformedValue)
}
